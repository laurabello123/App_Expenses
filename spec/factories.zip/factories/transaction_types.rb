FactoryBot.define do
  factory :transaction_type do
       name Faker::Pokemon.name
  end
end
